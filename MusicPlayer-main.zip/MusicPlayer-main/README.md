# MusicPlayer
##  This is a simple Music Player in python . This project is created for music lovers like me to listen songs with python...This is an opensource Project
# Images :
## <img src=https://raw.githubusercontent.com/swagkarna/MusicPlayer/main/img.png>
